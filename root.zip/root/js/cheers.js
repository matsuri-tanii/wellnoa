// keep using existing script — endpoint is cheer_toggle.php
