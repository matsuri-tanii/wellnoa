// keep using existing script — endpoint is save_article_read.php
