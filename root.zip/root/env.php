<?php
define('OPENWEATHER_API_KEY','d2bae2af195bb3f8ecf16ab3e107132d');

function sakura_db_info(){
  return [
    "db_name" => "wellnoa_wellnoa",
    "db_host" => "mysql3109.db.sakura.ne.jp",
    "db_id"   => "wellnoa_wellnoa",
    "db_pw"   => "comvyF-tapnoj-cogwi4",
  ];
}

if (!defined('ADMIN_USER')) define('ADMIN_USER','admin');
if (!defined('ADMIN_PASSWORD')) define('ADMIN_PASSWORD','wellnoachangesme');

define('BASE_URL', 'https://wellnoa.sakura.ne.jp');
?>
