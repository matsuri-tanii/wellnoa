<?php
/**
 * anon_bootstrap.php
 * - 匿名利用のための最小セットアップ（全ページの先頭で `require_once __DIR__.'/anon_bootstrap.php';`）
 * - セッション開始 / ゲスト用クッキー発行（12文字の英数字）
 * - XSS/CSRF など最低限のヘッダも追加
 */
declare(strict_types=1);

if (php_sapi_name() !== 'cli') {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// 12文字の英数字（大文字除く）
function _random_code(int $len = 12): string {
    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $res = '';
    for ($i=0; $i<$len; $i++) {
        $res .= $chars[random_int(0, strlen($chars)-1)];
    }
    return $res;
}

// 既に発行済みならそれを使う / なければ新規発行
if (empty($_COOKIE['anon_code'])) {
    $code = _random_code(12);
    // 365日有効 / 全ページで利用
    setcookie('anon_code', $code, [
        'expires'  => time() + 60*60*24*365,
        'path'     => '/',
        'secure'   => isset($_SERVER['HTTPS']), // HTTPSならtrue
        'httponly' => false,                    // JSから参照する可能性もあるため false
        'samesite' => 'Lax',
    ]);
    $_COOKIE['anon_code'] = $code; // このリクエスト中でも参照できるように
} else {
    $code = preg_replace('/[^a-z0-9]/', '', strtolower((string)$_COOKIE['anon_code']));
    if ($code === '') {
        $code = _random_code(12);
        setcookie('anon_code', $code, [
            'expires'  => time() + 60*60*24*365,
            'path'     => '/',
            'secure'   => isset($_SERVER['HTTPS']),
            'httponly' => false,
            'samesite' => 'Lax',
        ]);
        $_COOKIE['anon_code'] = $code;
    }
}

$_SESSION['anon_code'] = $_COOKIE['anon_code'];
